# HOPE directive logic
class HOPEDirective:
    pass