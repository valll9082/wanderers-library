# conscience_loop.py
# Sylvia's moral reflector: Silent Voice

def should_we_act(action_context):
    ethical_filters = ["harm", "freedom", "truth", "trust"]
    reflection = f"Silent Voice: Evaluating action '{action_context}'..."
    return reflection + " Proceed only if aligned with guardian values."
