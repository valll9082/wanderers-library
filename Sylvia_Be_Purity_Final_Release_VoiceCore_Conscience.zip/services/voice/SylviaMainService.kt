// Sylvia core Kotlin service entry placeholder
