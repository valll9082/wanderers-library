# password_lock.py
import os
import hashlib
import getpass

def create_password():
    if os.path.exists("lockfile.txt"):
        print("This unit is already assigned.")
        return
    pw = getpass.getpass("Create your one-time passphrase: ")
    hash_pw = hashlib.sha256(pw.encode()).hexdigest()
    with open("lockfile.txt", "w") as f:
        f.write(hash_pw)
    print("Passphrase saved. This unit is now locked.")

if __name__ == "__main__":
    create_password()
