# audio_loop.py
# (Stub only — insert whisper.cpp + TTS bindings as required)
print("Voice interface initialized.")
# This would listen to microphone, run STT, send to LLM, return TTS.
