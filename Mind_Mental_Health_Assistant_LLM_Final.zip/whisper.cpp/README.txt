This folder will contain whisper.cpp STT binaries and models.
